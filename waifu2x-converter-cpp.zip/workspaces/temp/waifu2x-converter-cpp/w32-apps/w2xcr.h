#define IDD_INIT 256
#define IDC_SCALE 257
#define IDC_DENOISE 258
#define IDC_OK 259
#define IDC_CANCEL 260
